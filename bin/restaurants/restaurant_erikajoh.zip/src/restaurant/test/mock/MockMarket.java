package restaurant.test.mock;


import java.util.List;

import restaurant.CashierAgent;
import restaurant.CookAgent;
import restaurant.interfaces.Cashier;
import restaurant.interfaces.Market;

/**
 * A sample MockWaiter built to unit test a CashierAgent.
 *
 * @author Erika Johnson
 *
 */
public class MockMarket extends Mock implements Market {

	/**
	 * Reference to the Cashier under test that can be set by the unit test.
	 */
	public Cashier cashier;
	private String name;

	public MockMarket(String name) {
		super(name);
		this.name = name;
	}

	@Override
	public void msgNeedFood(CookAgent c, CashierAgent ca, String f, int amt){
		
	}
	
	public void msgHereIsPayment(CashierAgent c, double amt){
		log.add(new LoggedEvent("Received msgHereIsPayment."));
	}
	
	public String getName(){
		return this.name;
	}

}
