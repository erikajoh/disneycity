##Restaurant Project Repository

###Student Information
  + Name: Kelsey Rose
  + USC Email: kelseyro@usc.edu
  + USC ID: 2784678908
  + MW 4PM Lecture
  + T 9AM Lab
  + To Compile:
  + clone repository
  + import into eclipse 
  + add JUnit to the buildpath 
  + to make sure images are included, drag res file into Eclipse file structure. when I import the project into Eclipse, the res folder isn't automatically included for some reason. 
  + Run by pressing the green run button
  

###How To Run Test Cases for V2.1: 
####Normatives 
  + Note: Cook always starts with 7 of everything except Pizza and Latte. The first market has Pizza, the second has Lattes. The does his initial order before customers come. If you wait about 18 seconds for cook to order from both markets after he sees the first market is out of Lattes, the cook will be completely restocked when customers arrive.
  + 1) One of every type of agent: Add a customer and Waiter after waiting for kitchen to restock.
  + 2) No customers, cook orders low items: Run program. Do nothing. Cook will order low items before customers are added. 
  + 3) Multiple customers and waiters: Run program. Wait about 18 seconds for kitchen to restock before adding customers and waiters. 
  + 4) Waiter goes on and off break: Click on desired waiter, click Go On Break button. To take them off break, click them again in the list of waiters and then click Go Off Break. (The push button doesn't automatically update its text)


####Non Normatives 
  + 1) Customer orders, food has run out, orders something else: Run program. Add customer named "Latte" as soon as program opens (before Latte is reordered after 18 seconds). Customer will order Latte and then something else once told Latte is unavailable.
  + 2) Cook orders from Market, must order from backup market: Run program. Program already set up to order from backup market because the first market is initialized without Lattes.
  + 3) Waiter wants to go on break but can't: Add one waiter. Press Go On Break button. 
  + 4) Customer comes to restaurant, restaurant is full, wants to wait: Add 3 customers and then a customer called "Wait" (otherwise there is a 50% chance he will wait rather than leave)
  + 5) Customer comes to restaurant, restaurant is full, wants to leave: Add 3 customers and then a customer called "Leave"
  + 6) Customer doesn't have enough money to order anything, leaves : Add a customer called "Zero". This sets the customer's cash variable to 0.
  + 7) Customer has only enough money to order cheapest item: Wait until restaurant is restocked at beginning. Add a customer called "Four". This sets the customer's cash variable to 4. 
  + 8) Customer has only enough money to order cheapest item, they are out of item so he leaves: Run program. Add customer called "Four" before lattes are restocked. This sets the customer's cash variable to 4. 
  + 9) Customer orders, eats, but doesn't have enough money: Add customer called "SteakTen". This sets choice to Steak and cash to 10. Customer gives casher all his money, leaves, but stores an amount he still owes. When he returns to eat, he pays his overdue balance before he orders (Customers are given 20 dollars when they leave, as if to go home to get more money)

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)
