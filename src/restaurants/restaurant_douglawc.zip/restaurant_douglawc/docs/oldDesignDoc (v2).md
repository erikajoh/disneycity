#Design document for milestone v2A
==================

##Customer

###Data
+ Map menu;
+ Host host;
+ Waiter myWaiter;
+ String name;
+ String order;
+ int tableNumber;
+ int hungerLevel;
+ AgentState state {None, WaitingToBeSeated, FollowingWaiter, ReadingMenu, ReadyToOrder, GivingOrder, WaitingForFood, Eating, ReadyToLeave, Leaving};

###Messages
	msgGoToTable(int table, Map menu) {
		tableNumber = table;
		this.menu = menu;
		state = FollowingWaiter;
	}
	msgWhatWouldYouLike() {
		state = GivingOrder;
	}
	msgFoodArrived() {
		state = Eating;
	}

###Scheduler
	if(state == None) GotHungry();
	else if(state == ReadingMenu) CallWaiterForOrder();
	else if(state == ReadyToOrder) GiveOrder();
	else if(state == ReadyToLeave) CallWaiterForCheck();
	else if(state == Leaving) LeaveRestaurant();
	... // more conditionals similar to above, one for each state

###Actions
	GotHungry() {
		host.msgIWantToEat(this);
	}
	CallWaiterForOrder() {
		myWaiter.msgIAmReadyToOrder();
	}
	ReadingMenu() {
		use timer to wait for specified amount of time
			then, set appropriate state/event to signal in scheduler to tell waiter that I am ready to order
	}
	CallingWaiter() {
		waiter.msgIAmReadyToOrder(this);
	}
	GiveOrder() {
		myWaiter.msgGivingMyOrder();
	}
	EatFood() {
		use timer to wait for specified amount of time
			then, set appropriate state/event to signal in scheduler to tell waiter that I am ready to leave
	}
	CallWaiterForCheck() {
		myWaiter.msgDoneEating();
	}
	LeaveRestaurant() {
		myWiater.msgReadyToLeave();
	}


##Host

###Data
+ LinkedList<MyCustomer> customers;
+ LinkedList<MyWaiter> waiters;
+ LinkedList<Table> tables;
+ MyCustomer {
	Customer c;
	int table;	
	AgentState s;
}
+ MyWaiter {
	Waiter waiter;
	AgentState state;
}
+ Table {
	Customer c;
}

###Messages
	msgAddWaiter(WaiterAgent w) { // called from GUI
		MyWaiter tempMyWaiter = new MyWaiter(w);
		waiters.add(tempMyWaiter);
		stateChanged();
	}
	msgIWantToEat(Customer c) {
		customers.add(c);
	}
	msgTableIsFree(Waiter w, Table t) {
		remove t.c from customers
		t.c = null;
	}

###Scheduler
	if (there exists c in customers such that c.state == WaitingToBeSeated
		AND there exists t in tables such that t.c == null
		AND there exists a waiter w such that w.state == available)
		seatCustomer(c, w, t);
	/* In v2B, my initial method of choosing the waiter is:
		keep an integer representing an index in customers
		assign waiter at this index to seat customer
		increment index (resets to 0 when index == waiters.size()) */

###Actions
	seatCustomer(Customer c,  Waiter w, Table t) {
		w.msgSeatCustomer(c, w, t);
		t.setCustomer = c;
	}


##Waiter

###Data
+ Map<String, Double> menu;
+ List<MyCustomer> customers;
+ CustomerState {None, WaitingToBeSeated, FollowingWaiter, ReadyToOrder, GaveOrder, WaitingForFood, FoodIsComing, Eating, ReadyToLeave, Leaving};
+ MyCustomer {
	Customer c;
	int table;
	String order;
	CustomerState s;
}

###Messages
	msgSeatCustomer(Customer c, Table t) {
		customers.add(c);
		c.table = t;
	}
	msgIAmReadyToOrder(Customer c) {
		ReadyToOrder(c);
	}
	msgGivingMyOrder(Customer c, String choice) {
		MyCustomer mc = customers.find(c);
		mc.order = choice;
	}
	msgOrderReady(int tableNum, String order) {
		MyCustomer mc = customers.find(c);
		mc.state = FoodIsComing;
	}
	msgDoneEating(Customer c) {
		mc.s = DoneEating;
	}
	msgReadyToLeave(Customer c) {
		CusomterLeaving(c);
	}

###Scheduler
	if (there exist c in customers such that c.s == WaitingToBeSeated)
		SeatCustomer(c);
	if (there exist mc in customers such that mc.s == ReadyToOrder) {
		GoToCustomer(mc);
		TakeOrder(mc);
	}
	if (there exist c in customers such that c.s == GaveOrder) {
		GoToCook(mc.table, mc.order);
		mc.state = WaitingForFood;
	}
	if (there exist mc in customers such that mc.s == DoneEating) {
		GoToCustomer(mc);
		CustomerLeaving(mc);
	}

###Actions
	SeatCustomer(Customer c, int table, Map menu) {
		c.msgFollowMe(table);
		DoGoToTable(c);
		c.s = seated;
		c.menu = menu;
	}
	ReadyToOrder(Customer c) {
		MyCustomer mc = customers.find(c);
		mc.s = ReadyToOrder;
	}
	GoToCustomer(MyCustomer mc) {
		DoGoToCustomer(mc.c);
	}
	TakeOrder(MyCustomer mc) {
		mc.c.msgWhatWouldYouLike();
		mc.s = asked;
	}
	GoToCook(int table, string order) {
		cook.msgNewOrder(this, table, order);
	}
	CustomerLeaving(Customer c) {
		host.msgTableIsFree(c.tableNumber);
		customers.remove(c);
	}


##Cook

###Data
+ Map<String, int> recipeTimes;
+ List<Order> orders;
+ OrderState {NotReady, BeingPrepared, Ready};
+ Order {
	Waiter waiter;
	String order;
	int tableNum;
	long recieveTime;
	OrderState = state;
}

###Messages
	msgNewOrder(Waiter w, int tableNum, String order) {
		Order o = new Order(w, order, tableNumber);
		orders.add(o);
	}
	msgOrderDone(String choice, int table) {
		o.state = OrderState.Ready;
		stateChanged();
	}

###Scheduler
	while (there exist o in orders s.t. difference between current system time and o.receiveTime is greater than recipeTimes.get(o.order))
		OrderIsReady(o);

###Actions
	PrepareOrder(Order o) {
		long currentTime = System.currentTimeMillis();
		print("PrepareOrder() called");
		set timer to run for amount of time as determined by order type
			call msgOrderDone(o.order, o.tableNum) when done
	}
	OrderIsReady(Order o) {
		Waiter w = o.waiter;
		w.msgOrderReady(o);
		DoGiveOrderToWaiter(o);
		remove o from orders;
	}
