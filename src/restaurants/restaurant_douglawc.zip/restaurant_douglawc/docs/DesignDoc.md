#Design document for milestone v2A
==================

##Market

###Data
+ Map menu;
+ LinkedList<MarketOrder> marketOrders;
+ MarketOrder {
	String foodType;
	int amount;
}

###Messages
	msgNeedFood(MarketOrder mo) {
		add mo to marketOrders
	}

###Scheduler
	if(!marketOrders.isEmpty()) {
		MarketOrder currOrder = remove head from marketOrders
		int amountToGive = min(inventory.get(currOrder.foodType), currOrder.amount);
		MarketOrder returnOrder = new MarketOrder(currOrder.foodType, amountToGive);
		int oldInventoryAmt = inventory.get(currOrder.foodType);
		inventory.put(currOrder.foodType, oldInventoryAmt - amountToGive);
		GiveCookSupplies(returnOrder);
	}

###Actions
	GiveCookSupplies(MarketOrder mo) {
		cook.msgHereIsResupply(mo);
	}

##Cashier

###Data
+ Map menu;
+ ArrayList<MyCustomer> myCustomers;
+ ArrayList<Check> checks;
+ MyCustomer {
	CustomerAgent cust;
	CustomerState customerState {NewCustomer, ValidPayment, InvalidPayment};
}

###Messages
	msgCustomerNeedsCheck(WaiterAgent w, String order, CustomerAgent customer) {
		amountDue = order's price in menu
		newCheck = new Check(order, customer, amountDue)
		checks.add(newCheck);
	}
	
	msgPayingMyCheck(CustomerAgent c, Check check, double payment) {
		if(there exists MyCustomer mc such that mc.customer == c) {
			if(payment < check.amountDue)
				set mc.customerState to InvalidPayment
			else
				set mc.customerState to ValidPayment
		}
	}

###Scheduler
	for(Check aCheck in checks) {
		
		if(aCheck.state == CheckState.NewCheck) {
			deliverCheck(aCheck.waiter, aCheck);
		}
		
		if(aCheck.state == CheckState.PaidByCustomer) {
			CustomerAgent customerOnCheck = aCheck.customer;
			MyCustomer mc = the MyCustomer object corresponding to customerOnCheck
			if(mc.customerState == CustomerState.ValidPayment)
				handleValidPayment(aCheck);
			else
				handleInvalidPayment(aCheck);
		}
	}

###Actions

	deliverCheck(WaiterAgent freeWaiter, Check aCheck) {
		aCheck.waiter.msgHereIsCheck(aCheck);
	}
	
	handleValidPayment(Check aCheck) {
		remove aCheck from checks
		aCheck.customer.msgLeaveRestaurant();
	}
	
	handleInvalidPayment(Check aCheck) {
		CustomerAgent customerOnCheck = aCheck.customer;
		tell customer that he has debt
		remove aCheck from checks
		aCheck.customer.msgLeaveRestaurant();
	}


##Customer

###Data
+ Map menu;
+ Host host;
+ Waiter myWaiter;
+ Check myCheck;
+ String name;
+ String order;
+ int tableNumber;
+ int hungerLevel;
+ AgentState state {DoingNothing, WaitingToBeSeated, FollowingWaiter, ReadingMenu, ReadyToOrder,
	GivingOrder, WaitingForFood, Eating, ReadyToLeaveTable, GoingToCashier, CashierProcessing, Leaving};

+ double money;
+ boolean flaky = false;

###Messages
	msgMustWait() {
		if(customer gets impatient by random chance) {
			event = AgentEvent.leaving;
		}
	}
	msgCannotAffordAnything() {
		event = AgentEvent.cannotAffordAnything;
	}
	msgGoToTable(int table, Map menu) {
		tableNumber = table;
		this.menu = menu;
		state = FollowingWaiter;
	}
	msgWhatWouldYouLike() {
		state = GivingOrder;
	}
	msgFoodArrived() {
		state = Eating;
	}
	msgHereIsCheck(Check aCheck) {
		myCheck = aCheck;
		event = AgentEvent.waiterBroughtCheck;
	}

###Scheduler
	if(state == None) GotHungry();
	else if(state == ReadingMenu) CallWaiterForOrder();
	else if(state == ReadyToOrder) GiveOrder();
	else if(state == ReadyToLeave) CallWaiterForCheck();
	else if(state == Leaving) LeaveRestaurant();
	... // more conditionals similar to above, one for each state
	... // may leave early when event = cannotAffordAnything

###Actions
	GotHungry() {
		host.msgIWantToEat(this);
	}
	CallWaiterForOrder() {
		myWaiter.msgIAmReadyToOrder();
	}
	ReadingMenu() {
		use timer to wait for specified amount of time
			then, set appropriate state/event to signal in scheduler to tell waiter that I am ready to order
	}
	CallingWaiter() {
		waiter.msgIAmReadyToOrder(this);
	}
	GiveOrder() {
		myWaiter.msgGivingMyOrder();
	}
	EatFood() {
		use timer to wait for specified amount of time
			then, set appropriate state/event to signal in scheduler to tell waiter that I am ready to leave
	}
	CallWaiterForCheck() {
		myWaiter.msgDoneEating();
	}
	LeaveRestaurant() {
		myWiater.msgReadyToLeave();
	}


##Host

###Data
+ LinkedList<MyCustomer> customers;
+ LinkedList<MyWaiter> waiters;
+ LinkedList<Table> tables;
+ MyCustomer {
	Customer c;
	int table;	
	AgentState s;
}
+ MyWaiter {
	Waiter waiter;
	AgentState state;
}
+ Table {
	Customer c;
}

###Messages
	msgAddWaiter(WaiterAgent w) { // called from GUI
		MyWaiter tempMyWaiter = new MyWaiter(w);
		waiters.add(tempMyWaiter);
		
	}
	msgIWantToEat(Customer c) {
		customers.add(c);
	}
	msgTableIsFree(Waiter w, Table t) {
		remove t.c from customers
		t.c = null;
	}
	msgWantToGoOnBreak(WaiterAgent incomingWaiter) {
		incomingWaiter.state = WaiterState.WorkingAndWantBreak;
	}
	msgDoneWithBreak(WaiterAgent incomingWaiter) {
		incomingWaiter.state = WaiterState.Working;
	}

###Scheduler
	if (there exists c in customers such that c.state == WaitingToBeSeated
		AND there exists t in tables such that t.c == null
		AND there exists a waiter w such that w.state == available)
		seatCustomer(c, w, t);
	/* In v2B, my initial method of choosing the waiter is:
		keep an integer representing an index in customers
		assign waiter at this index to seat customer
		increment index (resets to 0 when index == waiters.size()) */

###Actions
	seatCustomer(Customer c,  Waiter w, Table t) {
		w.msgSeatCustomer(c, w, t);
		t.setCustomer = c;
	}
	approveBreak(MyWaiter mw) {
		mw.waiter.msgApproveBreak();
	}
	denyBreak(MyWaiter mw) {
		mw.waiter.msgDenyBreak();
	}


##Waiter

###Data
+ Map<String, Double> menu;
+ List<MyCustomer> customers;
+ List<Check> checks;
+ CustomerState {None, WaitingToBeSeated, FollowingWaiter, ReadyToOrder,
		WaitingToOrder, GaveOrder, ReadyToOrderAgain, WaitingForFood, FoodIsComing, Eating,
		DoneWithMeal, WaitingForCheck, CheckIsComing, LeavingTable};
+ MyCustomer {
	Customer c;
	int table;
	String order;
	CustomerState s;
}

###Messages
	msgSeatCustomer(Customer c, Table t) {
		customers.add(c);
		c.table = t;
	}
	msgIAmReadyToOrder(Customer c) {
		ReadyToOrder(c);
	}
	msgGivingMyOrder(Customer c, String choice) {
		MyCustomer mc = customers.find(c);
		mc.order = choice;
	}
	msgOutOfThisOrder(int tableNum, String order) {
		customer.state = ReadyToOrderAgain;
	}
	msgOrderReady(int tableNum, String order) {
		MyCustomer mc = customers.find(c);
		mc.state = FoodIsComing;
	}
	msgNeedCheck(CustomerAgent c) {
		MyCustomer mc = findCorrespondingMyCustomer(c); 
		mc.state = CustomerState.DoneWithMeal;
	}
	
	msgHereIsCheck(Check aCheck) {
		checks.add(aCheck);
		CustomerAgent customer = aCheck.customer;
		MyCustomer mc = findCorrespondingMyCustomer(customer);
		mc.state = CustomerState.CheckIsComing;
	}
	msgReadyToLeave(Customer c) {
		CusomterLeaving(c);
	}

###Scheduler
	if (there exist c in customers such that c.s == WaitingToBeSeated)
		SeatCustomer(c);
	if (there exist mc in customers such that mc.s == ReadyToOrder) {
		GoToCustomer(mc);
		TakeOrder(mc);
	}
	if (there exist c in customers such that c.s == GaveOrder) {
		GoToCook(mc.table, mc.order);
		mc.state = WaitingForFood;
	}
	if (there exists mc in customers such that mc.s == DoneEating) {
		GoToCustomer(mc);
		CustomerLeaving(mc);
	}
	//etc.

###Actions
	SeatCustomer(Customer c, int table, Map menu) {
		c.msgFollowMe(table);
		DoGoToTable(c);
		c.s = seated;
		c.menu = menu;
	}
	ReadyToOrder(Customer c) {
		MyCustomer mc = customers.find(c);
		mc.s = ReadyToOrder;
	}
	TakeOrder(MyCustomer mc) {
		mc.c.msgWhatWouldYouLike();
		mc.s = asked;
	}
	GoToCook(int table, string order) {
		cook.msgNewOrder(this, table, order);
	}
	CustomerLeaving(Customer c) {
		host.msgTableIsFree(c.tableNumber);
		remove c from customers;
	}
	GoToCashierToGetCheck(MyCustomer mc) {
		cashier.msgCustomerNeedsCheck(this, mc.order, mc.c);
	}


##Cook

###Data
+ Map<String, int> recipeTimes;
+ List<Order> orders;
+ OrderState {NotReady, BeingPrepared, Ready};
+ Order {
	Waiter waiter;
	String order;
	int tableNum;
	long recieveTime;
	OrderState = state;
}
+ List<MyMarket> designatedMarkets;
+ MyMarket {
	MarketAgent market;
}

###Messages
	msgNewOrder(Waiter w, int tableNum, String order) {
		Order o = new Order(w, order, tableNumber);
		orders.add(o);
	}
	msgOrderDone(String choice, int table) {
		o.state = OrderState.Ready;
	} 
	msgHereIsResupply(MarketOrder mo) {
		if(mo.amount == 0) {
			render this market obsolete for particular food type 
			select new market for this food type
		}
		int oldInvAmt = inventory.get(mo.foodType);
		inventory.put(mo.foodType, oldInvAmt + mo.amount);
	}

###Scheduler
	while (there exist o in orders s.t. difference between current system time and o.receiveTime is greater than recipeTimes.get(o.order))
		OrderIsReady(o);
	if(any food is out)
		call Restock, include o as parameter;
	if(waiter requests food through o)
		TellWaiterWeAreOut(o);

###Actions
	TellWaiterWeAreOut(Order o) {
		WaiterAgent waiter = o.waiter;
		waiter.msgOutOfThisOrder(o.tableNum, o.order);
		orders.remove(o);
	}
	PrepareOrder(Order o) {
		long currentTime = System.currentTimeMillis();
		print("PrepareOrder() called");
		set timer to run for amount of time as determined by order type
			call msgOrderDone(o.order, o.tableNum) when done
	}
	OrderIsReady(Order o) {
		Waiter w = o.waiter;
		w.msgOrderReady(o);
		DoGiveOrderToWaiter(o);
		remove o from orders;
	}
	Restock(MarketOrder mo) {
		int indMarketToQuery = designatedMarkets.get(mo.foodType);
		if(indMarketToQuery < myMarkets.size()) {
			MyMarket theMarket = myMarkets.get(indMarketToQuery);
			theMarket.market.msgNeedFood(mo);
		}
	}
