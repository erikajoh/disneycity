##Restaurant Project Repository

###Student Information
  + Name: Douglass Chen
  + User name: douglawc
  + USC email: douglawc@usc.edu
  + USC ID: 2304800148
  + Course section: MW 12:00 PM - 1:50 PM
  + Lab section: Tuesday 9:00 AM - 10:50 AM

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)

###Issues/notes with v2.2
  + You can combine the Money and food parameters from v2.1; e.g., to create a customer who wants steak and has 25 dollars, the name should be "Money Steak 25" or "Steak Money 25" (note the money amount must be last).
  + Extra credit for what happens when cashier cannot pay bill in full (one of the unit tests should cover this):
    + Cashier starts off with $10. At the start of the program, Cook will always attempt to restock inventory for all three food types, so he will make three orders in all. All food orders cost $5 regardless of restock amount, so the first two payments would go through normally, and the third one would send the cashier into debt. The cashier will try to make up this debt on future payments (by that time cashier should have more money received from customers).
  + The cook will display (fz) and (d) next to the order it is currently managing. These mean "frozen" (food was just taken from fridge) and "done" respectively (food is now ready and heading to plating area).
  + Extra credit for going to refridgerator is enabled.
  + Bug: Spamming customers asking for the same food may throw null pointer exceptions, make customers stuck at tables forever, and/or assign multple customers to same table.

###Interaction diagrams - UPDATED FOR v2.1
  + My interaction diagram for the normative scenarios is split up among five image files.
    + v2 scenarios: v2-interaction-diagram.gif
    + Cashier scenarios: v2.1-interaction-diagram-cashier.jpg
    + When cook orders from market: v2.1-interaction-diagram-order-from-market.png
    + When cook runs out of food and customer wants it: v2.1-interaction-diagram-run-out-of-food
    + When waiter wants break: v2.1-interaction-diagram-waiter-wants-break.png

###Compile/Run Instructions
  + Open Eclipse. Navigate to File -> New -> Other...
  + In the window that pops up, select "Java Project from Existing Ant Buildfile".
  + Click Browse... and select the build.xml file inside this git repository.
  + Select the declaration that pops up, and click Finish.
  + In the project folder (called "agents"), open src/restaurant.gui, right-click the "RestaurantGui.java" file, and select Run As... -> Java Application to run the program.

###How to run the scenarios (v2.1)
  1. To force customer to initially order a particular item (steak/salad/pizza), enter "Steak", "Salad", or "Pizza" for customer name (quotes for clarity, case must match). Note that the customer must have enough money.
    + If the food is out of stock or customer cannot afford the food he wants, customer will try to order something else.
  2. Customer displays amount of money on hand when he enters restaurant. To force money amount for customer, enter "Money #" for customer, where # is the DOUBLE value of the cash the customer has on hand. Note that in this case the customer is honest and will leave the restaurant if he can't afford the cheapest item (by default this is "Pizza" which is 5.00, so if customer has less than that he leaves).
    + For the case where a "flaky" customer decides to order something without having enough money, enter "Money -1". Here, customer has no money but will order something at random. The cashier, upon recognizing invalid payment, will print message "Next time you come, pay up this debt" in console.
  3. To allow waiter to go on break, click on box containing waiter's name in scroll pane, then check the "Want break?" checkbox in the info panel below. Uncheck the box for waiter to get back to work. (If break is denied, box will still be checked; to refresh this, uncheck and check the box again.)
  4. By default, customers have a 50-50 chance of leaving if the restaurant is full. (search for 'impatient' to find the appropriate code segments)
  5. By default, among all three markets and the cook, there are only four of each food type in this simulation (all markets and cook start off with 1 of each). To simulate markets/cook running out, keep ordering the same item.
  6. For testing the following:
    + (2 points) Customers who have only enough money to order the cheapest item will only order that cheap item.
      (2 points) Customers who have only enough money to order the cheapest item will leave if that item is out of stock.
    create customers all with name "Money 5" so that they will only order Pizzas and will leave when pizzas run out (see scenario #5 above).

###Issues/notes with v2.1
  + In console: Max is the Host, the Planets (A, B, C) are the Markets, Marvin is the Cook, and Deep Thought is the Cashier
  + When waiter goes to get check, he goes off the right edge of the screen, as that's where the cashier is located.
  + The same customer will replenish his money when he leaves the restaurant. A newly instantiated customer agent will start off with a random amount of money (unless scenario #2 from above is done).
  + Based on this quote from the rubric, "Customers who have no money to order anything sometimes chooses to order anyway and ends up without enough money to pay," I'm assuming it is NEVER the case that an honest customer (not set to "Money -1") with insufficient money orders food.
  + There MAY be cases where a customer gets stuck at table or waiter gets stuck at cashier - this seems to be visible only when customers are added en masse (spamming the add customer button too many times), and may have to do with either cook unable to supply any foods while the customer is present. If customers are added gradually (no more than 1 per second) it should be fine.

###How to run the scenarios (v2)
  1. One customer, one waiter: "Add waiter; nothing happens; add customer; normative scenario should run. Then, make customer hungry again."
    + Top-right corner contains agent creation window. Go to Waiter tab inside agent creation window, enter waiter name, and click "Add Waiter" button.
    + Then, go to customer tab, enter customer's name, check the "Hungry?" checkbox just below the text field, and click "Add Customer" button. The animation should now run.
    + Note that when customer is created, a rectangle with customer's name appears in the scroll pane. Once animation finishes, click the customer's name in the scroll pane, then in the Information box below check the "Hungry?" checkbox to restart.

  2. Multiple customers, one waiter: "Add customer; nothing happens. Add waiter; normative scenario should start. Add another customer. Should be seated at second table. Then, make customer hungry again."
    + Add customer with "Hungry?" checkbox checked as demonstrated in scenario #1. Add waiter; animation should now start. Add another customer before animation ends (can be same name as the first customer).
    + Make customer hungry again as demonstrated in scenario #1.

  3. Load the tables, one waiter: "Add waiter; nothing happens; add customer; normative scenario should start; Add another customer. Should be seated at second table; Then, make customer hungry again."
    + Same process as is in scenario #2, but the order of customer and waiter agent is reversed.

  4. Multiple waiters, multiple customers: "Add two waiters; Add two customers; make sure both waiters are assigned customers, i.e., the waiter assignment mechanism is working in the HostAgent; Keep adding customers to exceed the number of tables. Tables should be filled and customers will be waiting."
    + Specify waiter name. Click the "Add waiter" button multiple times. Specify customer name. Click the "Add customer" button multiple times.

  5. "Pause/Restart button should work in any of the above scenarios." More specifically, pause button would cause agents to stop only after they finish all their current tasks.

###Issues/notes with v2
  + Pause button is in Waiter tab only.
  + The pause button may not stop agents' animations immediately because an agent may have to finish several animations chained together before stopping. For instance, pausing a waiter while he is seating a customer may not prevent him from heading back to entrance after seating customer. In this situation, though, he will not move until pause button is pressed again.
  + Though this shouldn't affect the basic scenarios in the rubric, there is a small issue with waiter scheduling: suppose a bunch of customers are added at once, and then a single waiter is added. The waiter will only seat one customer at a time, not the rest.
    + To have the waiter seat multiple customers, first create the waiter, then add the customers.
  + Note: In the default menu, salad takes a long time (10 seconds). Program may seem paused but it's not. If one wants to change cook times, they have to modify the last number in each line in the MenuTextFile.txt, located in agents/src/res.
