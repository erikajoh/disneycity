package restaurant;

import restaurant.interfaces.Market;

public class FoodBill {
	public String order;
	public Market market;
	public double amountDue;
	public FoodBill(String aOrder, Market aMarket, double anAmountDue) {
		order = aOrder;
		market = aMarket;
		amountDue = anAmountDue;
	}
}
