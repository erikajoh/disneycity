package restaurant.gui;

import javax.imageio.ImageIO;
import javax.swing.*;

import restaurant.HostAgent;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class AnimationPanel extends JPanel implements ActionListener {

    private final int WINDOW_X = 800;
    private final int WINDOW_Y = 700;
    private final int CASHIER_X = 400;
    private final int CASHIER_Y = 600;
    private final int PERSON_WIDTH = 50;
    private final int PERSON_HEIGHT = 50;
    private final int TIMER_INTERVAL = 4;
    
    private final int PLATING_X = 210;
    private final int PLATING_Y = 140;
    private final int PLATING_WIDTH = 130;
    private final int PLATING_HEIGHT = 5;
    private final int FRIDGE_X = 245;
    private final int FRIDGE_Y = 0;
    private final int COOKING_X = 400;
    private final int COOKING_Y = 50;
    private final int COOKING_WIDTH = 200;
    private final int COOKING_HEIGHT = 50;
    
    private final int TEXT_OFFSET = 15;
    private final int LABEL_FONT = 14; 
    
    private BufferedImage bi;

    private List<Gui> guis = new ArrayList<Gui>();

    public AnimationPanel() {
    	setSize(WINDOW_X, WINDOW_Y);
        setVisible(true);
        
        try {
        	bi = ImageIO.read(new File(getClass().getResource("/img/restaurant-bg.jpg").toURI()));
		} catch (Exception e) {
			e.printStackTrace();
		}
 
    	Timer timer = new Timer(TIMER_INTERVAL, this);
    	timer.start();
    }

	public void actionPerformed(ActionEvent e) {
		repaint();  //Will have paintComponent called
	}

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g;

        //Clear the screen by painting a rectangle the size of the frame
        g2.setColor(getBackground());
        //g2.fillRect(PERSON_INITX, PERSON_INITY, WINDOWX, WINDOWY );
        g2.drawImage(bi, 0, 0, null);
        
        //Hard-coded animation objects here
        //These are the tables
        g2.setColor(Color.ORANGE);
        for(int i = 0; i < HostAgent.NTABLES; i++) {
        	g2.fillRect(Gui.xTable + Gui.tableSpacing*i, Gui.yTable, PERSON_WIDTH, PERSON_HEIGHT);        	
        }
        
        //This is the cashier
        g2.setColor(Color.BLUE);
        g2.fillRect(CASHIER_X, CASHIER_Y, PERSON_WIDTH, PERSON_HEIGHT);
        
        //These are the cook's three zones
        g2.setColor(Color.GRAY);
        g.setFont(new Font(null, Font.BOLD, LABEL_FONT));
        g2.fillRect(PLATING_X, PLATING_Y, PLATING_WIDTH, PLATING_HEIGHT);//plating
        g2.fillRect(FRIDGE_X, FRIDGE_Y, PERSON_WIDTH, PERSON_HEIGHT);//fridge
        g2.fillRect(COOKING_X, COOKING_Y, COOKING_WIDTH, COOKING_HEIGHT);//cooking
        
        //Zone labeling
        g2.setColor(Color.YELLOW);
        g.drawString("Fridge", FRIDGE_X, FRIDGE_Y + TEXT_OFFSET);
        g.drawString("Cooking area", COOKING_X, COOKING_Y + TEXT_OFFSET);
        
        g2.setColor(Color.BLUE);
        g2.fillRect(CASHIER_X, CASHIER_Y, PERSON_WIDTH, PERSON_HEIGHT);
        
        for(Gui gui : guis) {
            if (gui.isPresent()) {
                gui.updatePosition();
            }
        }

        for(Gui gui : guis) {
            if (gui.isPresent()) {
                gui.draw(g2);
            }
        }
        
    }

    public void addGui(Gui gui) {
        guis.add(gui);
    }
}
