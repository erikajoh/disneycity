package restaurant.interfaces;

import restaurant.CookAgent;
import restaurant.MarketOrder;

public interface Market {

	//TODO: CashierMarket interaction step 3
	public abstract void msgHereIsBill(double amount, boolean lastBillFulfilled);

	public abstract String getName();

}