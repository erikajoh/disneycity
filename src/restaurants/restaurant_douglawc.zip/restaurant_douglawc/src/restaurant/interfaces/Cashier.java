package restaurant.interfaces;

import restaurant.Check;
import restaurant.FoodBill;

public interface Cashier {

	public abstract void msgCustomerNeedsCheck(Waiter w, String order,
			Customer customer);

	public abstract void msgPayingMyCheck(Customer c, Check check,
			double payment);

	public abstract void msgHereIsBill(FoodBill fb);
}