package restaurant;

public class MarketOrder {
	public String foodType;
	public int amount;
	public MarketOrder(String aFoodType, int anAmount) {
		foodType = aFoodType;
		amount = anAmount;
	}
}
