package restaurant.test.mock;

import restaurant.CookAgent;
import restaurant.MarketOrder;
import restaurant.interfaces.Cashier;
import restaurant.interfaces.Market;

public class MockMarket extends Mock implements Market {

	public Cashier cashier;
	public EventLog log;
	
	public MockMarket(String name) {
		super(name);
		log = new EventLog();
	}

	@Override
	public void msgHereIsBill(double amount, boolean lastBillFulfilled) {
		if(lastBillFulfilled) {
			log.add(new LoggedEvent("msgHereIsBill from cashier: valid payment"));
		}
		else {
			log.add(new LoggedEvent("msgHereIsBill from cashier: invalid payment"));
		}
	}
	
	@Override
	public String getName() {
		return name;
	}
}
