##Restaurant Project Repository

###Student Information
  + Name: Douglass Chen
  + User name: douglawc
  + USC email: douglawc@usc.edu
  + USC ID: 2304800148
  + Course section: MW 12:00 PM - 1:50 PM
  + Lab section: Tuesday 9:00 AM - 10:50 AM

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)

###Compile/Run Instructions
  + Open Eclipse. Navigate to File -> New -> Other...
  + In the window that pops up, select "Java Project from Existing Ant Buildfile".
  + Click Browse... and select the build.xml file inside this git repository.
  + Select the declaration that pops up, and click Finish.
  + In the project folder (called "agents"), open src/restaurant.gui, right-click the "RestaurantGui.java" file, and select Run As... -> Java Application to run the program.

###How to run the scenarios
  1. One customer, one waiter: "Add waiter; nothing happens; add customer; normative scenario should run. Then, make customer hungry again."
    + Top-right corner contains agent creation window. Go to Waiter tab inside agent creation window, enter waiter name, and click "Add Waiter" button.
    + Then, go to customer tab, enter customer's name, check the "Hungry?" checkbox just below the text field, and click "Add Customer" button. The animation should now run.
    + Note that when customer is created, a rectangle with customer's name appears in the scroll pane. Once animation finishes, click the customer's name in the scroll pane, then in the Information box below check the "Hungry?" checkbox to restart.

  2. Multiple customers, one waiter: "Add customer; nothing happens. Add waiter; normative scenario should start. Add another customer. Should be seated at second table. Then, make customer hungry again."
    + Add customer with "Hungry?" checkbox checked as demonstrated in scenario #1. Add waiter; animation should now start. Add another customer before animation ends (can be same name as the first customer).
    + Make customer hungry again as demonstrated in scenario #1.

  3. Load the tables, one waiter: "Add waiter; nothing happens; add customer; normative scenario should start; Add another customer. Should be seated at second table; Then, make customer hungry again."
    + Same process as is in scenario #2, but the order of customer and waiter agent is reversed.

  4. Multiple waiters, multiple customers: "Add two waiters; Add two customers; make sure both waiters are assigned customers, i.e., the waiter assignment mechanism is working in the HostAgent; Keep adding customers to exceed the number of tables. Tables should be filled and customers will be waiting."
    + Specify waiter name. Click the "Add waiter" button multiple times. Specify customer name. Click the "Add customer" button multiple times.

  5. "Pause/Restart button should work in any of the above scenarios." More specifically, pause button would cause agents to stop only after they finish all their current tasks.

###Issues/notes with v2
  + Pause button is in Waiter tab only.
  + The pause button may not stop agents' animations immediately because an agent may have to finish several animations chained together before stopping. For instance, pausing a waiter while he is seating a customer may not prevent him from heading back to entrance after seating customer. In this situation, though, he will not move until pause button is pressed again.
  + There may be concurrent modification problems (which can be ignored for now).
  + Though this shouldn't affect the basic scenarios in the rubric, there is a small issue with waiter scheduling: suppose a bunch of customers are added at once, and then a single waiter is added. The waiter will only seat one customer at a time, not the rest.
    + To have the waiter seat multiple customers, first create the waiter, then add the customers.
  + Note: In the default menu, salad takes a long time (10 seconds). Program may seem paused but it's not. If one wants to change cook times, they have to modify the last number in each line in the MenuTextFile.txt, located in agents/src/res.