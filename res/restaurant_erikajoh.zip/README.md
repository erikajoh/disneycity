##Restaurant Project Repository

###Student Information
  + Name: Erika Johnson
  + USC Email: erikajoh@usc.edu
  + USC ID: 3892385661
  + Lecture: MW 4pm
  + Lab: Tu 9am

###Compile Instructions
  + Compile and run in Eclipse.
  + The restaurant is initialized with 4 tables, 1 host, 1 cook, 1 cashier, 0 markets, 0 waiters, and 0 customers. To add a customer, type the name of the customer, select whether the customer is hungry, and press "add a customer". To add a waiter, select whether the waiter wants to go on break (does not necessarily mean he will be allowed to go on break) and press "add a waiter". To add a market, select whether the market is empty and press "add a market". All markets are initialized with 3 of each menu item by default. The cook is initialized with 0 of each menu item by default, so to run any normative scenario you will need to add at least 1 market that is not empty. When adding customers, the name should reflect the menu item you would like the customer to order. This is not caps sensitive. Customers are initialized with $100 in their wallet by default. If you would like to initalize a customer who has $0 in his wallet and will leave when he realizes he can't order anything, you should name him "broke". If you would like to initialize a customer who has $0 in his wallet and orders food anyway, you should name him "bad". If you would like to initialize a customer who has only enough money to order the cheapest item on the menu, you should name him "cheap". If the restaurant is full, customers will leave the restaurant by default. If you would like to create a customer who will stay and wait, name him "wait". You can use the GUI checkboxes to set a customer to "hungry" again after he is done eating (or if he has chosen to leave the restaurant when the restaurant was full), or to set a waiter on and off break (checked means on break, unchecked means off break, so to tell him to end his break, you should uncheck his checkbox), or to empty a market. Once you empty a market, the market checkbox will remain checked and you will not have the opportunity to restock the market.
  + v2 upgrades: the market bills the cashier. In the normative case, one order will be fulfilled by one market. To test the case where on order is fulfilled by two markets, you must create two markets and two customers must order the same item. Then, the cook will place an order for two more of that food item and it will have to be fulfilled by both markets (because the first market will only have 1 left of that item). The cashier is initialized with enough money to pay for an order resulting from two customers only, so to see the cashier not have enough money (and thus get cut off/blacklisted by that market), you should create three customers (along with waiters and two markets). Animation upgrades include a waiting area for customers, waiters, and a kitchen with a refrigerator, plating area, and cooking area.

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)
  + [Design Docs](design)

###Screenshot
![scrnshot](/design/screenshot.png)