package restaurant.interfaces;

import java.util.List;

import restaurant.CashierAgent;
import restaurant.CookAgent;
import restaurant.MarketAgent;
import restaurant.MarketAgent.Payment;
import restaurant.MarketAgent.Request;

/**
 * A sample Waiter interface built to unit test a CashierAgent.
 *
 * @author Erika Johnson
 *
 */
public interface Market {
	
	public void msgNeedFood(CookAgent c, CashierAgent ca, String f, int amt);
	
	public void msgHereIsPayment(CashierAgent c, double amt);
	
	public String getName();

}