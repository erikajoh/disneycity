package restaurant.interfaces;

import java.util.List;

import restaurant.WaiterAgent;
import restaurant.CashierAgent.Check;
import restaurant.CustomerAgent.AgentEvent;
import restaurant.CustomerAgent.AgentState;
import restaurant.HostAgent.Menu;

/**
 * A sample Customer interface built to unit test a CashierAgent.
 *
 * @author Monroe Ekilah
 *
 */
public interface Customer {
	public void msgFollowMeToTable(WaiterAgent w, Menu m, List<String> uf);
	
	public void msgAnimationFinishedGoToSeat();
	
	public void msgWhatWouldYouLike();
	
	public void msgOrderHasBeenReceived();
	
	public void msgHereIsYourFood();

	public void msgAnimationFinishedLeaveRestaurant();
	
	public void msgAnimationFinishedGoToCashier();
	
	public void msgPleaseReorder(List<String> uf);
	
	public void msgHereIsYourCheck(Check c);
	
	public void msgHereIsChange(double amt);
	
	public void msgDoDishesAsPunishment(int time);

}