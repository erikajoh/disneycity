package restaurant.interfaces;

import restaurant.interfaces.Waiter;
import restaurant.gui.Check;
import restaurant.gui.Menu;

/**
 * A sample Customer interface built to unit test a CashierAgent.
 *
 * @author Dylan Eirinberg
 *
 */
public interface Customer {
	public void msgGotHungry();
	
	public void msgRestaurantFull();

	public void msgFollowMe(Waiter w, int tn, Menu m);
	
	public void msgAskOrder();
	
	public void msgReorder();
	
	public void msgHereIsFood();
	
	public void msgHereIsCheck(Check c);
	
	public void msgHereIsChange(double change);
	
	public void msgCleanDishes();

	public int getNumber();

}