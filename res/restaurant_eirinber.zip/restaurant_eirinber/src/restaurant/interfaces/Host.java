package restaurant.interfaces;

import restaurant.interfaces.Customer;
import restaurant.interfaces.Waiter;

public interface Host {
	public void msgIWantFood(Customer cust);
	
	public void msgIWantToBreak(Waiter w);
	
	public void msgFinishedBreak(Waiter w);
	
	public void msgTableAvailable(Customer cust);
	
	public void msgCustomerLeaving(Customer cust);

}