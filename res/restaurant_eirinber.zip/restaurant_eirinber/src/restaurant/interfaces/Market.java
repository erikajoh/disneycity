package restaurant.interfaces;

import restaurant.MarketAgent.Order;
import restaurant.gui.Food;
import restaurant.interfaces.Cook;

public interface Market {
	public void msgPaidBill(double total, boolean fullyPaid);
	
	public void msgHereIsOrder(Cook c, Food f, int amt);
	
	public void msgFulfilledOrder(Order o);
	
	public int getFoodAmount(Food f);
	
	public String getName();
	
	public void setStock(Food f, int amt);
	
	public void setAllStockToAmt(int amt);
}