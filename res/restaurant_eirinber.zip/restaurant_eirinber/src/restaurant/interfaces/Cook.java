package restaurant.interfaces;

import restaurant.CookAgent.Order;
import restaurant.gui.Food;
import restaurant.interfaces.Cook;
import restaurant.interfaces.Waiter;

public interface Cook {
	public void msgHereIsOrder(Waiter w, String choice, Integer table);
	
	public void msgFulfilledOrder(Food food, int amount);
	
	public void msgOutOfFood(Food f, int ex);
	
	public void msgFoodDone(Order o);
	
	public String getName();

}