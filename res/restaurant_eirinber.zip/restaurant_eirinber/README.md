##Restaurant Project Repository

###Student Information
  + Name: Dylan Eirinberg
  + USC Email: eirinber@usc.edu
  + USC ID: 2229057817
  + Username: dylane629
  + Section: 30303
  + Lab: 30237


To compile, run an executable version of the code in Eclipse. Type in a name in the text field and press the add button below either the waiters or the customers labels.

To put a waiter on break. Click on his label and select "On break" in the bottom-left panel.

###Test Cases
+ Milestone 2.2A-one order, fulfilled by the market, bill paid in full 
+ Milestone 2.2A-one order, fulfilled by TWO markets, 2 bills paid in full
+ One customers, normative scenario
+ Multiple customers, out of order interactions w/ cashier
+ Multiple customers, out of order interactions w/ cashier and also ordering from a market at the same time
+ Multiple customers, out of order interactions w/ cashier and also ordering from TWO markets at the same time

###To run non-normative scenarios follow these directions:
####v2.2
Enter a customer with the name "Markets" to have the cashier order from multiple markets

Having the cashier order from a single market can be triggered by the v2.1 non-norms below

Enter a customer with the name "BrokeCashier" to have the cashier be out of money when ordering from the market

####v2.1
Enter a customer with the name "Broke" to have a customer arrive without enough money to order anything and then leave once it sees the menu.

Enter a customer with the name "Cheap" to have a customer arrive and order the cheapest item on the menu.

Enter a customer with the name "Unlucky" to have a customer order the cheapest item, only for that item to run out and then the customer leaves.  <b>NOTE:</b> when a customer named "Unlucky" enters the restaurant the cook and market run out of supply of the cheapest item. The markets are emptied so the cook doesn't get more food from them after an earlier customer orders. This will affect all other customers in the restaurant ordering the cheapest item as well. No bugs occur in this scenario.

Enter a customer with the name "Flaky" to have a customer arrive, eat, but not have enough money to pay. He will be sent by the cashier to the cook to clean dishes before he can leave.

Other non-norms should occur more frequently by chance.

Email me if you have any issues triggering the non-norms or any other problems with the program.

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)
