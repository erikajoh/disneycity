package restaurant.gui;

import restaurant.CashierAgent;
import restaurant.CookAgent;
import restaurant.CustomerAgent;
import restaurant.HostAgent;
import restaurant.WaiterAgent;
import restaurant.MarketAgent;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Vector;

import javax.swing.JTabbedPane;

/**
 * Panel in frame that contains all the restaurant information,
 * including host, cook, waiters, and customers.
 */
public class RestaurantPanel extends JPanel {

    //Host, cook, waiters and customers
    private HostAgent host = new HostAgent("Marco Rossi");
    private CashierAgent cashier = new CashierAgent("Ryo Hazuki");
    CookAgent cook;
    
    private Vector<MarketAgent> markets = new Vector<MarketAgent>();
    private Vector<CustomerAgent> customers = new Vector<CustomerAgent>();
    private Vector<WaiterAgent> waiters = new Vector<WaiterAgent>();
    
    private boolean isPaused = false;
    
    private JPanel restLabel = new JPanel();
    private ListPanel customerPanel = new ListPanel(this, "Customers");
    private ListPanel waiterPanel = new ListPanel(this, "Waiters");
    private JPanel group = new JPanel();

    private RestaurantGui gui; //reference to main gui
    
    private JPanel creditsPanel;
    private JLabel nameLabel;
    private JLabel pictureLabel;
    private ImageIcon personalPicture; 
    
    private JTabbedPane restruantPane = new JTabbedPane();

    public RestaurantPanel(RestaurantGui gui) {
        this.gui = gui;
        //host.setGui(hostGui);

        //gui.animationPanel.addGui(hostGui);
        host.startThread();
        cashier.startThread();
        cashier.setMenu(host.getMenu());
        
        cook = new CookAgent("Vivi");
        CookGui cG = new CookGui(cook, gui);
        gui.animationPanel.addGui(cG);
        cook.setGui(cG);
        cook.startThread();
        cook.setMenu(host.getMenu());
        cook.setCashier(cashier);
        
        
        MarketAgent tempMarket;
        tempMarket = new MarketAgent("Best Market", 5000, 10, 0, 6, 10);
        tempMarket.startThread();
        cook.addMarket(tempMarket);
        tempMarket.setCook(cook);
        markets.add(tempMarket);
        
        tempMarket = new MarketAgent("The Other Market", 7000, 7, 4, 8, 0);
        tempMarket.startThread();
        cook.addMarket(tempMarket);
        tempMarket.setCook(cook);
        markets.add(tempMarket);
        
        tempMarket = new MarketAgent("Easy & Fresh", 10000, 3, 6, 4, 9);
        tempMarket.startThread();
        cook.addMarket(tempMarket);
        tempMarket.setCook(cook);
        markets.add(tempMarket);
        
        /*
        //Temporary Hack to test Waiters
        waiter1 = new WaiterAgent("Reimu");
        waiter2 = new WaiterAgent("Hibiya");
        waiter1.setHost(host);
        waiter2.setHost(host);
        waiter1.setCook(cook);
        waiter2.setCook(cook);
        waiter1.setGui(new WaiterGui(waiter1, gui));
        waiter2.setGui(new WaiterGui(waiter2, gui));
        gui.animationPanel.addGui(waiter1.getGui());
        gui.animationPanel.addGui(waiter2.getGui());
        waiter1.startThread();
        waiter2.startThread();
        host.msgGiveJob(waiter1);
        host.msgGiveJob(waiter2);
        waiters.add(waiter1);
        waiters.add(waiter2);
        //End Hack
        */
        
        

        setLayout(new GridLayout(1, 1));
        group.setLayout(new GridLayout(1, 3, 10, 10));

        group.add(customerPanel);

        initRestLabel();
        
        personalPicture = new ImageIcon("../" + "Media" + File.separator + "Daron.jpg");
        nameLabel = new JLabel("GUI upgrade by Daron Lee");
        pictureLabel = new JLabel("", personalPicture, JLabel.CENTER);
        creditsPanel = new JPanel();
        creditsPanel.add(nameLabel);
        creditsPanel.add(pictureLabel);
        //add(creditsPanel);
        
        restruantPane.addTab("Menu", restLabel);
        restruantPane.addTab("Customers", group);
        restruantPane.addTab("Waiters", waiterPanel);
        restruantPane.addTab("Credits", creditsPanel);
        
        add(restruantPane);
        //add(restLabel);
        //add(group);
    }

    /**
     * Sets up the restaurant label that includes the menu,
     * and host and cook information
     */
    private void initRestLabel() {
        JLabel label = new JLabel();
        //restLabel.setLayout(new BoxLayout((Container)restLabel, BoxLayout.Y_AXIS));
        restLabel.setLayout(new BorderLayout());
        label.setText(
                "<html><h3><u>Tonight's Staff</u></h3><table><tr><td>host:</td><td>" + host.getName() + "</td></tr></table><h3><u> Menu</u></h3><table><tr><td>Steak</td><td>$15.99</td></tr><tr><td>Chicken</td><td>$10.99</td></tr><tr><td>Salad</td><td>$5.99</td></tr><tr><td>Pizza</td><td>$8.99</td></tr></table><br></html>");

        restLabel.setBorder(BorderFactory.createRaisedBevelBorder());
        restLabel.add(label, BorderLayout.CENTER);
        restLabel.add(new JLabel("               "), BorderLayout.EAST);
        restLabel.add(new JLabel("               "), BorderLayout.WEST);
    }

    /**
     * When a customer or waiter is clicked, this function calls
     * updatedInfoPanel() from the main gui so that person's information
     * will be shown
     *
     * @param type indicates whether the person is a customer or waiter
     * @param name name of person
     */
    public void showInfo(String type, String name) {

        if (type.equals("Customers")) {

            for (int i = 0; i < customers.size(); i++) {
                CustomerAgent temp = customers.get(i);
                if (temp.getName() == name)
                    gui.updateInfoPanel(temp);
            }
        }
        
        if (type.equals("Waiters")) {
        	for (WaiterAgent waiter : waiters) {
        		if(waiter.getName() == name) {
        			gui.updateInfoPanel(waiter);
        		}
        	}
        }
    }

    /**
     * Adds a customer or waiter to the appropriate list
     *
     * @param type indicates whether the person is a customer or waiter (later)
     * @param name name of person
     */
    public void addPerson(String type, String name) {

    	if (type.equals("Customers")) {
    		CustomerAgent c = new CustomerAgent(name);	
    		CustomerGui g = new CustomerGui(c, gui);

    		gui.animationPanel.addGui(g);// dw
    		c.setHost(host);
    		c.setGui(g);
    		customers.add(c);
    		c.startThread();
    		if(customerPanel.getHungry()) {
    			//c.gotHungry();
    			c.getGui().setHungry();
    		}
    	}
    	if(type.equals("Waiters")) {
    		WaiterAgent w = new WaiterAgent(name);
    		WaiterGui g = new WaiterGui(w, gui);
    		
    		gui.animationPanel.addGui(g);// dw
    		w.setHost(host);
    		w.setCashier(cashier);
    		w.setGui(g);
    		host.msgGiveJob(w);
    		w.setCook(cook);
    		waiters.add(w);
    		w.startThread();
    	}
    }
    
    public void pause() {
    	if(isPaused) {
    		isPaused = false;
    		cook.unpause();
    		host.unpause();
    		for(CustomerAgent c : customers) {
    			c.unpause();
    		}
    		for(WaiterAgent w : waiters) {
    			w.unpause();
    		}
    		gui.animationPanel.unpauseAnim();
    	}
    	
    	else {
    		isPaused = true;
    		cook.pause();
    		host.pause();
    		for(CustomerAgent c : customers) {
    			c.pause();
    		}
    		for(WaiterAgent w : waiters) {
    			w.pause();
    		}
    		gui.animationPanel.pauseAnim();
    	}
    }
}
