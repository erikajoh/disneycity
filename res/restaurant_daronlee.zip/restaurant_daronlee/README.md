##Restaurant Project Repository

###Student Information
  + Name: Daron Lee
  + USC Email: daronlee@usc.edu
  + USC ID: 6773486249
  + Lecture Section: MW 12:00-1:30
  + Lab Section: T 9:00-11:00
  
###Running and Compiling Code
  Nothing out of the norm for running and compiling the code.

###Running the Scenarios 
  + Go to the tabbed pane containing the type of person you want to create (customer or watier)
  + Type in the name of the person in the text field and click add (You may select or deselect the hungry text box if a customer is being created).
  + Created people can be accessed in their respective tabs.
  
There are hacks for customers to make them order different food and come in with different money. All the hacks deal with names.
  + "Angus" - Always Orders Steak
  + "Vegan Steve" - Always orders salad and only has enough money for a salad
  + "Chico" - Always orders chicken
  + "Hobo Joe" - Comes in With No Money (and leaves)
  + "College Student" - Comes in with some money (may order food he can't pay for)
  
The system is set up to order chicken and salad automatically from the markets. Chicken is fulfilled by 2 markets.
The cashier has enough money to pay off 2 of these 3 orders. The last he incurs a late fee from the market of $10.00.
By creating a customer named "Angus" the restaurant should make enough money to pay off the debt. He will also cause an order of steak, which the cashier will attempt to pay off with the money he receives from Angus after he pays off the other bill.
  
  Running the JUnit tests is as normal. Choose the CashierTest.java and run it as a JUnit test.
  

###Bugs
  + A unreplicated race case where the waiter tried to seat a single customer multiple times
  + Unreplicated bug where waiter asked customer to reorder food twice and then stopped paying attention to the customer.
  + The break button will stop resetting if it keeps being clicked and the waiter cannot go on break. Click on the waiter again in the list of waiters to reset the button.

###Unfinished Aspects
  + No extras tables can be added.

###Resources
  + [Restaurant v1](http://www-scf.usc.edu/~csci201/readings/restaurant-v1.html)
  + [Agent Roadmap](http://www-scf.usc.edu/~csci201/readings/agent-roadmap.html)

  
