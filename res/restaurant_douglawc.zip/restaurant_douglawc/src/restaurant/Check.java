package restaurant;

import restaurant.CashierAgent.CheckState;
import restaurant.interfaces.Customer;
import restaurant.interfaces.Waiter;

public class Check {
	public String order;
	public Waiter waiter;
	public Customer customer;
	public double amountDue;
	public CheckState state;
	public Check(String aOrder, Waiter aWaiter, Customer aCustomer, double anAmountDue) {
		order = aOrder;
		waiter = aWaiter;
		customer = aCustomer;
		amountDue = anAmountDue;
		state = CheckState.NewCheck;
	}
}
