package restaurant.interfaces;

import restaurant.Check;
import restaurant.CookAgent;
import restaurant.HostAgent;
import restaurant.gui.WaiterGui;

public interface Waiter {

	public abstract void msgHereIsCheck(Check aCheck);
	
}
