package restaurant.interfaces;

import java.util.HashMap;

import restaurant.Check;
import restaurant.HostAgent;
import restaurant.gui.CustomerGui;

public interface Customer {

	public abstract void msgPaymentApproved();

	public abstract void msgPaymentInvalid();
	
	public abstract void msgLeaveRestaurant();
}